package com.zxtech.ess.module.auth.service;

public interface ITestMultiDatabaseService {
	String seconddbTest();
}
