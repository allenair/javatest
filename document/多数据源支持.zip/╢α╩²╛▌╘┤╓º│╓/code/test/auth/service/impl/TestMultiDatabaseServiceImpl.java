package com.zxtech.ess.module.auth.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zxtech.ess.module.auth.mapper.AuthMapper;
import com.zxtech.ess.module.auth.service.ITestMultiDatabaseService;
import com.zxtech.mdb.DataSource;
import com.zxtech.mdb.DynamicDataSourceHolder;

@Service("testMultiDatabaseService")
public class TestMultiDatabaseServiceImpl implements ITestMultiDatabaseService {
	@Autowired
	private AuthMapper authMapper;
	
	@Override
	@DataSource(DynamicDataSourceHolder.DATASOURCE2)
	public String seconddbTest() {
		List<Map<String, Object>> list = authMapper.secondDbList();
		StringBuilder sb = new StringBuilder();
		sb.append("RESULT:");
		list.stream().forEach(map->{
			sb.append("id:").append(map.getOrDefault("id", ""));
			sb.append("user_name:").append(map.getOrDefault("user_name", ""));
		});
		return sb.toString();
	}

}
