package com.zxtech.ess.module.auth.web;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zxtech.ess.module.auth.service.IAuthService;
import com.zxtech.ess.module.auth.service.ITestMultiDatabaseService;
import com.zxtech.platform.constant.ResultConstants;
import com.zxtech.platform.vo.UserBean;

@Controller
@RequestMapping("/test_db")
public class TestMultiDatabaseController {
	private static final Logger LOGGER = LoggerFactory.getLogger(TestMultiDatabaseController.class);
	
	@Autowired
	private ITestMultiDatabaseService testMultiDatabaseService;
	
	@Autowired
	private IAuthService authService;
	
	@RequestMapping(value = "/defaultdb.test", method = RequestMethod.GET)
	@ResponseBody
	public String defaultdb(UserBean user, String oldPasswd) {
		String result = ResultConstants.SUCCESS;
		try {
			result = authService.changeUserPasswd(user, oldPasswd);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			result = ResultConstants.ERROR;
		}
		return result;
	}
	
	@RequestMapping(value = "/seconddb.test", method = RequestMethod.GET)
	@ResponseBody
	public String seconddb() {
		return testMultiDatabaseService.seconddbTest();
	}
}
