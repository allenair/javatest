package com.zxtech.mdb;

public class DynamicDataSourceHolder {
	public static final String DEFAULT = "default";
    public static final String DATASOURCE2 = "datasource2";
	private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

	public static void setDataSourceType(String dataSourceType) {
		contextHolder.set(dataSourceType);
	}

	public static String getDataSourceType() {
		return contextHolder.get();
	}

	public static void clearDataSourceType() {
		contextHolder.remove();
	}
}
