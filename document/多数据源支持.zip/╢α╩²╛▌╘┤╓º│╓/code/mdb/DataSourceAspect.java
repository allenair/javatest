package com.zxtech.mdb;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DataSourceAspect {
	private static Logger log = LoggerFactory.getLogger(DataSourceAspect.class);
	
	@Before("@annotation(targetDataSource)")
    public void changeDataSource(JoinPoint point, DataSource targetDataSource) {
        log.debug("UseDataSource : {} > {}" + targetDataSource.value() + point.getSignature());
        DynamicDataSourceHolder.setDataSourceType(targetDataSource.value());
    }
	
	@Before(value = "execution(* com.zxtech.ess.module.**.web.*Controller.*(..))")
	public void defaultDataSource(JoinPoint point) throws Throwable {
		log.debug("UseDataSource : default > {}" + point.getSignature());
        DynamicDataSourceHolder.setDataSourceType(DynamicDataSourceHolder.DEFAULT);
	}
}
